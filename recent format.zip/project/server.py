import socket
import sys
from _thread import *
import ctrl

host = '127.0.0.1'#socket.gethostname()
port = 6666
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)


def caction(cmd):
    if cmd=='lighton':
        ctrl.turnonlight()
    elif cmd=='lightoff':
        ctrl.turnofflight()
    elif cmd=='dooropen':
        ctrl.dooropen()
    elif cmd=='doorclose':
       ctrl.doorclose()

try:
    s.bind((host, port))
except socket.error as e:
    print(str(e))
s.listen(5)
#print('Waiting for a connection.')
def threaded_client(conn):
    while True:
        data = conn.recv(2048)
        data =data.decode('utf-8')
        if data:
            caction(data)
        #conn.sendall(str.encode(reply))
    conn.close()


while True:
    conn, addr = s.accept()
    #print('connected to: '+addr[0]+':'+str(addr[1]))
    start_new_thread(threaded_client,(conn,))