from flexx import flx



class MessageBox(flx.Label):

    CSS = """
    .flx-MessageBox {
        overflow-y:scroll;
        background: #e8e8e8;
        border: 1px solid #444;
        margin: 3px;
    }
    """

    def init(self):
        super().init()
        global window
        self._se = window.document.createElement('div')

    def sanitize(self, text):
        self._se.textContent = text
        text = self._se.innerHTML
        self._se.textContent = ''
        return text

    @flx.action
    def add_message(self, name, msg):
        line = '<i>' + self.sanitize(name) + '</i>: ' + self.sanitize(msg)
        self.set_html(self.html + line + '<br />')


class ChatRoom(flx.PyWidget):
    """ This represents one connection to the chat room.
    """

    def init(self):
        with flx.HBox(title='Flexx chatroom demo'):
            flx.Widget(flex=1)
            with flx.VBox():
                self.name_edit = flx.LineEdit(placeholder_text='your name')
                self.people_label = flx.Label(flex=1, minsize=250)
            with flx.VBox(minsize=450):
                self.messages = MessageBox(flex=1)
                with flx.HBox():
                    self.msg_edit = flx.LineEdit(flex=1,
                                                 placeholder_text='enter message')
                    self.ok = flx.Button(text='Send')
            flx.Widget(flex=1)

        self._update_participants()

        @flx.reaction('ok.pointer_down', 'msg_edit.submit')
        <s:Button id="snickers"
              label="snickers"/>

        <s:Button id="kitkat"
                  label="kitkat"/>

        // add your event listeners somewhere like in onCreationComplete
        snickers.addEventListener(MouseEvent.CLICK, chocolate);
        kitkat.addEventListener(MouseEvent.CLICK, chocolate);

        private function chocolate(e:MouseEvent):void
        {
            // e.target is the component that has dispatched the event (a button in this case)
            var type:String = e.target.id;

            trace("button", type, "was clicked");

            if(type == "snickers")
            {
                // do stuff
            }
            else if(type == "kitkat")
            {
                // do something else
            }
        }

if __name__ == '__main__':
    a = flx.App(ChatRoom)
    a.serve()
    m = a.launch('browser')  # for use during development
    flx.start()
