import threading
status=['hi']
def test():
	import socket
	host = '0.0.0.0'#socket.gethostname()
	port = 6666
	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	s.bind((host, port))
	s.listen(5)
	conn, addr = s.accept()
	lstatus=''
	while True:
		if status[0]!=lstatus:
			conn.sendall(str.encode(status[0]))
			lstatus=status[0]
def start():
	t=threading.Thread(target=test)
	t.start()