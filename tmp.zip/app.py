from flask import Flask, render_template, request, redirect
import bot1 as Server
Server.start()
commandno1=[1]
app = Flask(__name__)
lstatus=['OFF']
dstatus=['CLOSED']
fstatus=['OFF']
@app.route('/', methods=['GET', 'POST'])
def login():
    global lstatus
    return render_template('login.html',light_status=lstatus[0],door_status=dstatus[0],fan_status=fstatus[0])
@app.route('/main', methods=['GET', 'POST'])
def index():
    global lstatus
    return render_template('index.html',light_status=lstatus[0],door_status=dstatus[0],fan_status=fstatus[0])

@app.route('/lightaction/<string:even>',methods=['POST','GET'])
def action(even):
    if even == "on":
        lstatus[0]="ON"
        subject='command'+str(commandno1[0])
        Server.status[0]="lighton"
        commandno1[0]=commandno1[0]+1
        return render_template('index.html',light_status=lstatus[0],door_status=dstatus[0],fan_status=fstatus[0])
    elif even == "off":
        lstatus[0]="off"
        subject='command'+str(commandno1[0])
        Server.status[0]="lightoff"
        commandno1[0]=commandno1[0]+1
        return render_template('index.html',light_status=lstatus[0],door_status=dstatus[0],fan_status=fstatus[0])
    else:
        return render_template('index.html',light_status=lstatus[0],door_status=dstatus[0],fan_status=fstatus[0])
@app.route('/dooraction/<string:deven>')
def daction(deven):
    if deven == "open":
        dstatus[0]="OPEN"
        subject='command'+str(commandno1[0])
        Server.status[0]="dooropen"
        commandno1[0]=commandno1[0]+1
        return render_template('index.html',door_status=dstatus[0],light_status=lstatus[0],fan_status=fstatus[0])
    elif deven == "close":
        dstatus[0]="CLOSED"
        subject='command'+str(commandno1[0])
        Server.status[0]="doorclose"
        commandno1[0]=commandno1[0]+1
        return render_template('index.html',door_status=dstatus[0],light_status=lstatus[0],fan_status=fstatus[0])
    else:
        return render_template('index.html',door_status=dstatus[0],light_status=lstatus[0],fan_status=fstatus[0])

@app.route('/fanaction/<string:feven>')
def fanaction(feven):
    if feven=="on":
        fstatus[0]="ON"
        Server.status[0]="fanon"
        return render_template('index.html', light_status=lstatus[0], door_status=dstatus[0],fan_status=fstatus[0])
    elif feven=="off":
        fstatus[0]="OFF"
        Server.status[0]="fanoff"
        return render_template('index.html', light_status=lstatus[0], door_status=dstatus[0],fan_status=fstatus[0])

@app.route('/logout', methods=['GET', 'POST'])
def logout():
    global lstatus
    return render_template('login.html',light_status=lstatus[0],door_status=dstatus[0],fan_status=fstatus[0])

if __name__ == "__main__":
    app.run('0.0.0.0','80')
